<template>
  <q-layout class="bg-dark text-white" view="hlHh Lpr lFf">
    <q-header elevated class="bg-grey-9 text-white" >
      <q-toolbar class="bg-dark text-white">
        
        <!-- <q-btn
          flat
          dense
          round
          icon="menu"
          aria-label="Menu"
          @click="leftDrawerOpen = !leftDrawerOpen"
        /> -->

        <q-toolbar-title>
          MOBILE STERILIZER
        </q-toolbar-title>

        <div>v1.0</div>
      </q-toolbar>
    </q-header>

    <!-- <q-drawer
      v-model="leftDrawerOpen"
      show-if-above
      bordered = "grey"
      content-class="bg-grey-9 text-grey"
    >
      <q-list>
        <q-item-label
          header
          class="bg-grey-9 text-grey"
        >
          CENAURA
        </q-item-label>
        <EssentialLink
          v-for="link in essentialLinks"
          :key="link.title"
          v-bind="link"
        />
      </q-list>
    </q-drawer> -->

    <q-page-container>
      <router-view />
    </q-page-container>
  </q-layout>
</template>

<script lang="ts">
import EssentialLink from 'components/EssentialLink.vue'

const linksData = [
  {
    title: 'CAMERA STREAM',
    caption: '',
    icon: 'video',
    link: '../pages/joypad'
  },
  {
    title: 'JOY PAD',
    caption: '',
    icon: 'game',
    link: '../pages/index'
  },
];

import { defineComponent, ref } from '@vue/composition-api';

export default defineComponent({
  name: 'MainLayout',
  components: { EssentialLink },
  setup() {
    const leftDrawerOpen = ref(false);
    const essentialLinks = ref(linksData);

    return {leftDrawerOpen, essentialLinks}
  }
});
</script>
