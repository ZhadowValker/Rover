<template>
  <q-page class="row items-center justify-evenly" color="#292029cc">
    <div class="q-pa-md fixed-bottom-right">
      <q-btn-dropdown
        push
        round
        icon="settings"
        class="flat"
        color="teal-10"
        text-color="grey"
        label=""
      >
        <div class="row no-wrap q-pa-md">
          <div class="column">
            <div q-mb-md></div>
            <q-form @submit="onSubmit" @reset="onReset" class="q-pa-md">
              <q-input
                filled
                v-model="ip"
                label="MOBILE STERILIZER'S IP ADDRESS"
                lazy-rules
              ></q-input>

              <q-input
                filled
                v-model="nav_port"
                label="NAVIGATION PORT NUMBER"
                lazy-rules
              ></q-input>

              <q-input
                filled
                v-model="uvc_port"
                label="UVC PORT NUMBER"
                lazy-rules
              ></q-input>

              <q-input
                filled
                v-model="cam_port"
                label="CAMERA PORT NUMBER"
                lazy-rules
              ></q-input>

              <div>
                <q-btn label="Submit" type="submit" color="grey" v-close-popup></q-btn>
                <q-btn
                  label="Reset"
                  type="reset"
                  color="grey"
                  flat
                  class="q-ml-sm"
                ></q-btn>
              </div>
            </q-form>
          </div>
        </div>
      </q-btn-dropdown>
     
    </div>
<!-- 
     <div class="q-px-sm q-py-lg">
      <q-video
        :ratio="1"
        src="http://192.168.0.166:4747/"
        style="width: 400px; height: 300px"
      ></q-video>
    </div>  -->
  
    <!-- <div id="live" class="q-px-sm q-py-lg" align="fixed-center">
        <iframe 
          width="320"
          height="205"
          src= http://{{ip}}:{{cam_port}}/live      
          title="ROBOT Live Stream"
          frameborder="0"
          allow="autoplay;picture-in-picture"
          allowfullscreen
        ></iframe>0
    </div> -->

      <div class="column items-center" style="margin-top: 0px; margin-bottom: 50px">
        <q-btn
          round
          push
          size="xl"
          color="blue-grey-10 "
          icon="keyboard_arrow_up" style="margin-top: 0px; margin-bottom: 0px"
          direction="up"
          class="{active:interval}"
          @mousedown="forward"
          @mouseup="stop"
          @touchstart="forward"
          @touchend="stop"
          @touchcancel="stop"
        >
        </q-btn>

        <div class="q-px-sm q-py-lg">
          <q-btn
            round
            push
            size="xl"
            color="blue-grey-10 "
            icon="keyboard_arrow_left"
            direction="left"
            class="{active:interval}"
            @mousedown="left"
            @mouseup="stop"
            @touchstart="left"
            @touchend="stop"
            @touchcancel="stop"
          ></q-btn>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <q-btn
            round
            push
            color="red-10"
            label="stop"
            size="xl"
            class="{active:interval}"
           
            @mousedown="stop"
            @touchstart="stop"
     
       
          ></q-btn>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <q-btn
            round
            push
            size="xl"
            color="blue-grey-10 "
            icon="keyboard_arrow_right"
            direction="right"
            class="{active:interval}"
            @mousedown="right"
            @mouseup="stop"
            @touchstart="right"
            @touchend="stop"
            @touchcancel="stop"
          ></q-btn>
        </div>

        <div class="column items-center">
          <q-btn
            round
            push
            size="xl"
            color="blue-grey-10 "
            icon="keyboard_arrow_down"
            direction="down"
            class="{active:interval}"
            @mousedown="backward"
            @mouseup="stop"
            @touchstart="backward"
            @touchend="stop"
            @touchcancel="stop"
          ></q-btn>
          <br />
          <br />
          <br />
          <br />
          <br />
          <br />
          <div class="q-pa-md fixed-bottom-left " style="margin-top: 0px; margin-bottom: 0px">
            <q-btn
              push
              icon="flare"
              color="positive"
              class="{active:interval}"
              @mousedown="uvc_on"
              @touchstart="uvc_on"
              >&nbsp; UVC ON</q-btn
            >
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <q-btn
              push
              icon="adjust"
              color="negative"
              class="{active:interval}"
              @mousedown="uvc_off"
              @touchstart="uvc_off"
              >&nbsp; UVC OFF</q-btn
            >
         
         <!-- <div class="column items-center" style="margin-top: 0px; margin-bottom: 0px">
        <q-btn
          round
          push
          size="xl"
          color="green"
          icon="star"
          direction="up"
          class="{active:interval}"
          @mousedown="start"
          @mouseup="stop"
          @touchstart="start"
          @touchend="stop"
          @touchcancel="stop"
        >
        </q-btn>
          </div> -->
        </div>
      </div>
    </div>
  </q-page>

</template>

<script lang="ts">
// import { Todo, Meta } from 'components/models';
import ExampleComponent from 'components/CompositionComponent.vue';
import { defineComponent } from '@vue/composition-api';
import axios from 'axios';

export default defineComponent({
  name: 'PageIndex',
  components: { ExampleComponent },
  data() {
    return {
      interval: null,
      count: 0,
      ip: '',
      nav_port: '',
      uvc_port: '',
      cam_port: '',
      uri: '',
      totalVuePackages: '',
      errorMessage: '',
      title: ''
    };
  },

  methods: {

     start() {
      axios
        .get(`http://${this.ip}:${this.nav_port}/start`)
        .then(
          function(response)
          { 
            console.log(response.data);
          // vm.title = response.data.title
          }
          )
        .catch(function(error) 
        {
          console.log(error);
          }
          );
    },

    // start() {
    //   if (!this.interval) {
    //     this.interval = setInterval(() => this.count++, 30); 
    //     axios
    //       .get(`http://${this.ip}:${this.nav_port}/start`)
    //       .then((response) => (this.totalVuePackages = response.data))
    //       .catch((error) => {
    //         this.errorMessage = error.message;
    //         console.error('There was an error!', error);
    //       });
    //   }<!-- var helloWorld = new HTMLString.String('http://{{ip}}:{{nav_port}}/start'); -->
    // },

    forward() {
      axios
        .get(`http://${this.ip}:${this.nav_port}/forward`)
        .then(
          function(response)
          { 
            console.log(response.data);
          // vm.title = response.data.title
          }
          )
        .catch(function(error) 
        {
          console.log(error);
          }
          );
    },

    backward() {
      axios
        .get(`http://${this.ip}:${this.nav_port}/backward`)
        .then(
          function(response)
          { 
            console.log(response.data);
          // vm.title = response.data.title
          }
          )
        .catch(function(error) 
        {
          console.log(error);
          }
          );
    },

    right() {
      axios
        .get(`http://${this.ip}:${this.nav_port}/right`)
        .then(
          function(response)
          { 
            console.log(response.data);
          // vm.title = response.data.title
          }
          )
        .catch(function(error) 
        {
          console.log(error);
          }
          );
    },

    left() {
      axios
        .get(`http://${this.ip}:${this.nav_port}/left`)
        .then(
          function(response)
          { 
            console.log(response.data);
          // vm.title = response.data.title
          }
          )
        .catch(function(error) 
        {
          console.log(error);
          }
          );
    },

    stop() {
          axios
        .get(`http://${this.ip}:${this.nav_port}/stop`)
        .then(
          function(response)
          { 
            console.log(response.data);
          // vm.title = response.data.title
          }
          )
        .catch(function(error) 
        {
          console.log(error);
          }
          );

    },
  

  uvc_on() {

    axios
        .get(`http://${this.ip}:${this.nav_port}/uvc_on`)
        .then(
          function(response)
          { 
            console.log(response.data);
          // vm.title = response.data.title
          }
          )
        .catch(function(error) 
        {
          console.log(error);
          }
          );
  },

  uvc_off()
  {
    axios
        .get(`http://${this.ip}:${this.nav_port}/uvc_off`)
        .then(
          function(response)
          { 
            console.log(response.data);
          // vm.title = response.data.title
          }
          )
        .catch(function(error) 
        {
          console.log(error);
          }
          );
    },

  onSubmit() {
    this.$q.notify({
      color: 'green-4',
      textColor: 'white',
      icon: 'cloud_done',
      message: 'saved',
    });
  },

  onReset() {
    this.ip = '';
    this.nav_port = '';
    this.uvc_port = '';
    this.cam_port = '';
  },
  }
}
);


</script>
