<template>
  <q-page class="row items-center justify-evenly">
    <!--
  Forked from:
  https://quasar.dev/vue-components/floating-action-button#Example--Expandable
-->
<div id="q-app">
<div class="q-px-sm q-py-lg" >
 <q-video
      :ratio="1"
      src="http://192.168.0.170:8000"
       style="width:400px;  height:300px"
    ></q-video> 
</div>
  </div>

  </q-page>


  

</template>


